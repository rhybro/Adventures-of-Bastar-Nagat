---
Type: faction
World: "Musketeers"
Campaign: "The Philosopher King"
Location: 
Faction: ""
Aliases: 
Active: True
Title: {{title}}>
Date_Created: {{date}}
Last_Modified: <% tp.date.now("DD-MM-YYYY HH:mm") %>
Tags: [faction]
---

# {{title}}**

### Structure

### Motivation

### Things I Know About Them

### Clues

### Notable or Known Members

### Relationships

---
 
