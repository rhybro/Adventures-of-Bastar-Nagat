---
Type: npc
World: "Musketeers"
Campaign: "The Philosopher King"
Location: 
Faction: ""
Deceased: False
Gender: 
Class:
Spellcaster: False
Title: "{{title}}"
Date Created: {{date}}
Last_Modified: {{date}}
Tags: [npc]
---

**{{title}}**

### Description 


- - - 

### Motivation


- - -
### Things they know


- - -
### Things the Players know about them


-  - -
### Clues


- - - 
### Relationships


---
 
