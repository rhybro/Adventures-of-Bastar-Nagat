---
Type: PC
World: "Musketeers"
Campaign: "The Philosopher King"
Location: 
Faction: "Musketeers"
Active: False
Deceased: False
Gender: Male
Lackey: False
Class:
Spellcaster: False
Title: "{{title}}"
Date Created: {{date}}
Last_Modified: {{date}}
Tags: [PC]
---

{{date}}**

### Background 


- - - 

### Motivation


- - -
### Things they know


-  - -
### Clues


- - - 
### Relationships


---
 
