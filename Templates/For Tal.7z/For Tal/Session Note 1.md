---
Type: session
World: "Musketeers"
Campaign: "The Philosopher King"
Season: 5
Episode: 
Chapter: ""
Location: Paris
Game_Date: 1636 
Title: <% tp.file.title %>
Date Created: <% tp.file.creation_date("DD-MM-YYYY HH:mm") %>
Last_Modified: <% tp.date.now("DD-MM-YYYY HH:mm") %>
Tags: [session]
---

# **<% tp.file.title %>**
## Prep

>[!todo] 
>### Checklist
> - [ ] Review Characters
> - [ ] Strong Start
> 					- [ ] What’s Happening?
> 		- [ ] What’s The Point?
> 		- [ ] Where’s The Action?
> 	- [ ] Outline Potential Scenes
> 	- [ ] Secrets and Clues
> 	- [ ] Fantastic Locations
> 	- [ ] Important NPCs
> 	- [ ] Relevant Monsters
> 	- [ ] Magic Item Rewards

### Secondary ToDo

- [ ] Add anything else that needs to be done per session here

### Session Summary
^summary


### Recap of Last Session
![]()
### Plot
—

### Episode Log
<% tp.file.cursor() %>

This is where I keep a record of what happened in the session