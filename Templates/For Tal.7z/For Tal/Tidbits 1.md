---
Type: tidbit
Author: 
Campaign: "The Philosopher King"
Location: ""
Title: <% tp.file.title %>
Date Created: <% tp.file.creation_date("DD-MM-YYYY HH:mm") %>
Last_Modified: <% tp.date.now("DD-MM-YYYY HH:mm") %>
Tags: [Longform, note]
---

# **<% tp.file.title %>**

<% tp.file.cursor() %>


